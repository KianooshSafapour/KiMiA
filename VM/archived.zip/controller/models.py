import asyncio
from sqlalchemy import create_engine, Column, Integer, String, update
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import select
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

Base = declarative_base()

class Transaction(Base):
    __tablename__ = 'transactions'

    id = Column(Integer, primary_key=True)
    ccn = Column(String(16))
    acn = Column(String(16))
    tcn = Column(String(20))
    date = Column(String(10))
    time = Column(String(10))
