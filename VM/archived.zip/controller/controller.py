import asyncio
import logging
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import select
from sqlalchemy import create_engine, Column, Integer, String, update
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import select
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
import bot_father   # Assuming this module contains the coroutines

Base = declarative_base()

DATABASE_URL = "sqlite+aiosqlite:///./database.sqlite3"  # Replace with your actual database URL
engine = create_async_engine(DATABASE_URL, echo=True)
async_session = sessionmaker(bind=engine, expire_on_commit=False, class_=AsyncSession)

async def login(driver,card_number):
    result = await bot_father.login(driver,card_number)
    return result

async def update(driver, semaphore, destination_card, from_date, from_time, to_date, to_time):
    print("###############updateupdateupdateupdateupdate####################")
    result = await bot_father.update_database(driver, semaphore, destination_card, from_date, from_time, to_date, to_time)
    return result
async def status(driver,card_number):
    result =await bot_father.check_login(driver,card_number)
    return result
async def awake(driver,card_number):
    result =await bot_father.refresh(driver,card_number)
    return result

async def check_transaction(driver, semaphore, customer_card, destination_card, transaction_code, from_date, from_time, to_date, to_time,):
    async with semaphore:
        async with async_session() as session:
            # Replace the following with your actual database query using SQLAlchemy
            print("#################################check_transactioncheck_transactioncheck_transactioncheck_transaction#####################################")
            transaction = await session.execute(
                "SELECT * FROM transactions WHERE ccn = :customer_card AND acn = :destination_card AND tcn = :transaction_code",
                {
                    "customer_card": customer_card,
                    "destination_card": destination_card,
                    "transaction_code": transaction_code,
                   
                }
            )
            result = transaction.fetchall()
            print(f"########################################################{result}")
            if result and len(result) > 0:
                return result[0]  #
            else:
                # If no transactions found, run the update function and check again
                update_result=await update(driver, semaphore, destination_card, from_date, from_time, to_date, to_time)
                # Replace the following with your actual database query after update
                print(f"update_result::::::{update_result}")
                if(update_result['status']=='success'):
                    transaction = await session.execute(
                        "SELECT * FROM transactions WHERE ccn = :customer_card AND acn = :destination_card AND tcn = :transaction_code",
                        {
                            "customer_card": customer_card,
                            "destination_card": destination_card,
                            "transaction_code": transaction_code,
                    
                        }
                    )
                    result = transaction.fetchall()
                    return result

# async def update_status(driver):
#     # Assuming update_status is a function in bot_father.py
#     await bot_father.update_status("available")