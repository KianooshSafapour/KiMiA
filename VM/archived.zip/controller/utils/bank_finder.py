def bank_finder(card_number):

    if card_number.startswith("585983"):
        return "tejarat"
    else:
        return None


